import React from 'react';

const Footer = () => {
    return (
        <div className='footer-main'>
            <div className='footer-block'>


            </div>
            
            </div>
    );
};

export default Footer;